//! Local-only model inspection for minimum reproductions. No native decoding outside the
//! existing guarded decoder. None of the returned models or labels are safe to share.
use std::collections::{BTreeMap, BTreeSet};
use std::panic::{catch_unwind, AssertUnwindSafe};

use cadmpeg_core::decode::{DecodeArena, DecodeContext, DecodeDepth};
use serde_json::Value;

use crate::{decode, Error, Model, Report};

/// Re-run only cadmpeg's checks on the retained model, without decoding or recovery.
pub fn check(model: &Model) -> Result<(), Error> {
    catch_unwind(AssertUnwindSafe(|| {
        decode::validate_decoded(
            &mut model.ir.clone(),
            DecodeDepth::Full,
            &decode::policy(),
            0,
            &mut Report::default(),
        )
    }))
    .unwrap_or_else(|_| {
        Err(Error::Decode(
            "the model checker failed unexpectedly".into(),
        ))
    })
}

/// A dependency-closed IR subset, seeded by one arena ordinal (zero based).
/// References stay unchanged in memory; no identities or geometry should be published.
/// A subset that cannot deserialize is refused, never repaired with invented geometry.
pub fn subset(model: &Model, arena: &str, ordinal: usize) -> Result<Model, String> {
    catch_unwind(AssertUnwindSafe(|| subset_guarded(model, arena, ordinal)))
        .unwrap_or_else(|_| Err("the model subset could not be built safely".into()))
}

fn subset_guarded(model: &Model, arena: &str, ordinal: usize) -> Result<Model, String> {
    let mut document = serde_json::to_value(&model.ir).map_err(|e| e.to_string())?;
    let homes = ["geometry", "model"];
    let arenas = || {
        homes
            .iter()
            .filter_map(|home| document.get(home)?.as_object())
            .flat_map(|home| home.values())
    };
    let count = arenas()
        .filter_map(Value::as_array)
        .try_fold(0usize, |sum, rows| sum.checked_add(rows.len()))
        .ok_or("subset entity limit reached")?;
    if count > 100_000 {
        return Err("subset entity limit reached".into());
    }
    let rows: BTreeMap<String, Value> = arenas()
        .filter_map(Value::as_array)
        .flatten()
        .filter_map(|row| Some((row.get("id")?.as_str()?.to_owned(), row.clone())))
        .collect();
    let arena =
        cadmpeg_ir::document::ArenaName::parse(arena).ok_or("subset arena is unavailable")?;
    let seed = document
        .get(arena.home().as_str())
        .and_then(|home| home.get(arena.key()))
        .and_then(Value::as_array)
        .and_then(|rows| rows.get(ordinal))
        .and_then(|row| row.get("id"))
        .and_then(Value::as_str)
        .ok_or("subset seed is unavailable")?
        .to_owned();
    let mut children: BTreeMap<&str, Vec<&str>> = BTreeMap::new();
    for (arena, parent) in [("regions", "body"), ("faces", "shell")] {
        for row in document
            .get("geometry")
            .and_then(|home| home.get(arena))
            .and_then(Value::as_array)
            .into_iter()
            .flatten()
        {
            if let (Some(parent), Some(id)) = (
                row.get(parent).and_then(Value::as_str),
                row.get("id").and_then(Value::as_str),
            ) {
                children.entry(parent).or_default().push(id);
            }
        }
    }
    let mut keep = BTreeSet::new();
    let mut queue = vec![seed];
    while let Some(id) = queue.pop() {
        if !keep.insert(id.clone()) {
            continue;
        }
        queue.extend(
            children
                .get(id.as_str())
                .into_iter()
                .flatten()
                .map(|id| (*id).to_owned()),
        );
        if let Some(row) = rows.get(&id) {
            references(row, &rows, &keep, &mut queue);
        }
    }
    for home in homes {
        for values in document
            .get_mut(home)
            .and_then(Value::as_object_mut)
            .into_iter()
            .flat_map(|home| home.values_mut())
            .filter_map(Value::as_array_mut)
        {
            values.retain(|row| {
                row.get("id")
                    .and_then(Value::as_str)
                    .is_some_and(|id| keep.contains(id))
            });
        }
    }
    let mut subset = model.clone();
    subset.ir = serde_json::from_value(document).map_err(|e| e.to_string())?;
    subset.fidelity = None;
    subset.assembly = None;
    subset.source_step = None;
    Ok(subset)
}

fn references(
    value: &Value,
    rows: &BTreeMap<String, Value>,
    keep: &BTreeSet<String>,
    queue: &mut Vec<String>,
) {
    match value {
        Value::String(id) if rows.contains_key(id) && !keep.contains(id) => queue.push(id.clone()),
        Value::Array(values) => {
            for value in values {
                references(value, rows, keep, queue);
            }
        }
        Value::Object(values) => {
            for (key, value) in values {
                if key != "name" && key != "label" {
                    references(value, rows, keep, queue);
                }
            }
        }
        _ => {}
    }
}

/// Local visitor for an archive member's ordinal, total, private name and decoded model.
pub type MemberVisitor<'a> = dyn FnMut(usize, usize, &str, Result<Model, Error>) -> bool + 'a;

pub use crate::decode::repro_members as members;

/// Structural specialization of parameter_domain. Uses the same carrier-domain query as
/// cadmpeg's check; does not inspect finding messages or reveal the range or carrier id.
pub fn use_curve_outside_carrier_count(model: &Model) -> u64 {
    use cadmpeg_ir::geometry::{CurveGeometry, SolvedCurveGeometry};
    let curves: BTreeMap<_, _> = model
        .ir
        .geometry
        .curves
        .iter()
        .map(|curve| (&curve.id, &curve.geometry))
        .collect();
    catch_unwind(AssertUnwindSafe(|| {
        model
            .ir
            .geometry
            .coedges
            .iter()
            .filter(|coedge| {
                let Some(use_curve) = &coedge.use_curve else {
                    return false;
                };
                match curves.get(&use_curve.curve).copied() {
                    None => true,
                    Some(CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(nurbs))) => {
                        let range = use_curve.parameter_range.endpoints();
                        cadmpeg_ir::eval::nurbs_curve_parameter_domain(nurbs)
                            .map(|domain| {
                                let domain = domain.endpoints();
                                // The pinned carrier check uses this public predicate and
                                // relative tolerance; keep classification consistent.
                                range.into_iter().any(|v| {
                                    !cadmpeg_ir::math::parameter_in_domain(v, domain, 1.0e-12)
                                })
                            })
                            .unwrap_or(true)
                    }
                    _ => false,
                }
            })
            .count() as u64
    }))
    .unwrap_or(0)
}

/// Entity arena kinds cited by structured error findings. The fixed arena names are safe;
/// referenced entity identities and checker messages never leave this function.
pub fn entity_kinds(model: &Model) -> Result<BTreeMap<String, u64>, Error> {
    catch_unwind(AssertUnwindSafe(|| {
        let arena = DecodeArena::new();
        let policy = decode::policy();
        let ctx = DecodeContext::for_loaded_input(&arena, &policy, 0)
            .map_err(|e| Error::Decode(e.to_string()))?;
        let validation =
            cadmpeg_ir::validate::validate_neutral_for_decode(&ctx, &model.ir, Vec::new())
                .map_err(|e| Error::Decode(e.to_string()))?;
        ctx.finish_session()
            .map_err(|e| Error::Decode(e.to_string()))?;
        let mut identities = BTreeMap::new();
        macro_rules! arenas { ($($arena:ident),+ $(,)?) => { $(
            for entity in &model.ir.geometry.$arena {
                identities.insert(entity.id.as_str(), stringify!($arena));
            }
        )+ }; }
        arenas!(
            bodies, regions, shells, faces, loops, coedges, edges, vertices, points, curves,
            surfaces, pcurves,
        );
        macro_rules! arenas { ($($arena:ident),+ $(,)?) => { $(
            for entity in &model.ir.model.$arena {
                identities.insert(entity.id.as_str(), stringify!($arena));
            }
        )+ }; }
        arenas!(
            features,
            sketches,
            parameters,
            product_definitions,
            occurrences
        );
        let mut counts = BTreeMap::<String, u64>::new();
        for finding in validation
            .findings
            .iter()
            .filter(|f| f.severity >= cadmpeg_ir::report::Severity::Error)
        {
            let ids: BTreeSet<_> = finding.entity.iter().chain(&finding.related).collect();
            for id in ids {
                *counts
                    .entry(
                        identities
                            .get(id.as_str())
                            .copied()
                            .unwrap_or("other")
                            .into(),
                    )
                    .or_default() += 1;
            }
        }
        Ok(counts)
    }))
    .unwrap_or_else(|_| {
        Err(Error::Decode(
            "the model checker failed unexpectedly".into(),
        ))
    })
}

pub use cadmpeg_registry::repro::{Bundle, CutOptions, Document, Signature};

/// Prove a bundle without exposing checker messages or entity identities.
pub fn verifies(bundle: &Bundle) -> bool {
    catch_unwind(AssertUnwindSafe(|| {
        if bundle.incomplete_reason.is_some() {
            return false;
        }
        cadmpeg_registry::repro::check(bundle)
            .iter()
            .any(|f| bundle.signature.reproduces(f))
    }))
    .unwrap_or(false)
}

/// Cut from the actual failing finding, widen to all row roots if needed, and reduce only
/// while the same signature reproduces. All native calls stay behind a panic guard.
pub fn bundle(
    document: &Document,
    options: &CutOptions,
    budget: std::time::Duration,
    cancel: &dyn Fn() -> bool,
) -> Result<Option<Bundle>, String> {
    catch_unwind(AssertUnwindSafe(|| {
        let arena = DecodeArena::new();
        let policy = decode::policy();
        let ctx = DecodeContext::for_loaded_input(&arena, &policy, 0)
            .map_err(|_| "The checker could not start.")?;
        let validation =
            cadmpeg_ir::validate::validate_neutral_for_decode(&ctx, document, Vec::new())
                .map_err(|_| "The checker could not finish.")?;
        ctx.finish_session()
            .map_err(|_| "The checker could not finish.")?;
        let Some(finding) = validation
            .findings
            .iter()
            .find(|f| f.severity >= cadmpeg_ir::report::Severity::Error)
        else {
            return Ok(None);
        };
        let signature = Signature::new(
            finding,
            document
                .source
                .as_ref()
                .map_or("cadir", |source| source.format()),
            cadmpeg_registry::repro::Stage::Check,
        );
        let initial = cadmpeg_registry::repro::cut(document, finding, options).ok();
        if initial
            .as_ref()
            .is_some_and(|cut| cut.incomplete_reason.is_some())
        {
            return Ok(None);
        }
        let cut = if let Some(cut) = initial.filter(verifies) {
            cut
        } else {
            if cadmpeg_ir::repro::projection_size(document, options).is_err() {
                return Ok(None);
            }
            let mut wider = finding.clone();
            let value =
                serde_json::to_value(document).map_err(|_| "The model could not be projected.")?;
            // Use the same graph visitor as cadmpeg; include native arenas too.
            wider.related = cadmpeg_ir::repro::rows(&value)
                .iter()
                .filter_map(|row| {
                    cadmpeg_ir::repro::record(&value, row)
                        .get("id")
                        .and_then(Value::as_str)
                        .map(str::to_owned)
                })
                .collect();
            let Ok(mut cut) = cadmpeg_registry::repro::cut(document, &wider, options) else {
                return Ok(None);
            };
            cut.signature = signature.clone();
            if !verifies(&cut) {
                return Ok(None);
            }
            cut
        };
        let reduced = cadmpeg_registry::repro::shrink(&cut, &signature, budget, cancel);
        Ok(Some(if verifies(&reduced) { reduced } else { cut }))
    }))
    .unwrap_or_else(|_| Err("The bundle checker stopped unexpectedly. No bundle was saved.".into()))
}

#[cfg(test)]
mod bundle_tests {
    #![allow(clippy::unwrap_used, clippy::indexing_slicing)]
    use super::*;
    use cadmpeg_ir::codec::write::Encoder;
    use std::time::Duration;

    fn cube() -> Document {
        crate::read(
            crate::Format::FusionArchive,
            &std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
                .join("tests/fixtures/generated_unit_cube.f3d"),
            &mut Report::default(),
        )
        .unwrap()
        .ir
    }

    #[test]
    fn synthetic_failure_survives_bundle_and_native_roundtrip() {
        let mut doc = cube();
        doc.geometry.points[0].set_position(
            cadmpeg_ir::math::Point3::new(50.0, 0.0, 0.0)
                .try_into()
                .unwrap(),
        );
        let refused = CutOptions {
            max_serialized_bytes: 1,
            ..Default::default()
        };
        assert!(bundle(&doc, &refused, Duration::ZERO, &|| false)
            .unwrap()
            .is_none());
        let original = doc.clone();
        let cut = bundle(&doc, &CutOptions::default(), Duration::ZERO, &|| false)
            .unwrap()
            .unwrap();
        assert!(verifies(&cut));
        assert_eq!(doc, original);
        let cancelled = bundle(
            &doc,
            &CutOptions::default(),
            Duration::from_secs(1),
            &|| true,
        )
        .unwrap()
        .unwrap();
        assert!(verifies(&cancelled));
        assert!(
            bundle(&cube(), &CutOptions::default(), Duration::ZERO, &|| false)
                .unwrap()
                .is_none()
        );
        let mut encoded = Vec::new();
        cadmpeg_codec_f3d::F3dCodec
            .plan(
                cadmpeg_ir::codec::write::EncodeInput::new(&doc, None),
                cadmpeg_ir::codec::write::target::TargetRequest::Inherit,
            )
            .unwrap()
            .write_to(&mut encoded)
            .unwrap();
        let read = crate::read_bytes(
            crate::Format::FusionArchive,
            std::path::Path::new("synthetic-failure.f3d"),
            &encoded,
            &mut Report::default(),
        );
        assert!(matches!(read, Err(Error::Checks { .. })));
        if let Ok(path) = std::env::var("DUTCHMAN_SYNTHETIC_FAILURE_OUT") {
            std::fs::write(path, &encoded).unwrap();
        }
    }
}
