//! Per-report consent, private local receipts and a bounded report transport.
use std::io::{Read, Write};
use std::path::{Path, PathBuf};
use std::time::Duration;

use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};

/// Fixed category for a file that converted but whose result the user reports as wrong.
pub const CONVERTED_PROBLEM_SIGNATURE: &str = "converted-with-problem";

pub const SCHEMA: &str = crate::json::REPORT_SEND;
/// The service limits the complete multipart body, including metadata and framing.
pub const MAX_REQUEST: usize = 25 * 1024 * 1024;
/// Leave room for metadata, consent and multipart framing even as reports evolve.
pub const MAX_BUNDLE: usize = MAX_REQUEST - 64 * 1024;
// Report boundaries are always SHA-256 hex digests (64 ASCII bytes).
const SIZE_BOUNDARY: &str = "0000000000000000000000000000000000000000000000000000000000000000";
pub const SIZE_NOTICE: &str = "The bundle plus reserved metadata and upload overhead exceeds the 25 MiB send limit. Use the private-send card or send an anonymous summary.";
const MAX_REPORT: usize = 16 * 1024;

/// Only a replay-verified, minimal repro provider should implement this seam.
/// Names must describe roles, never source names. Bytes can contain private geometry.
pub trait BundleSource {
    fn parts(&self) -> Result<Vec<BundlePart>, String>;
    fn manifest(&self) -> Value {
        json!([])
    }
}

pub struct BundlePart {
    pub role: String,
    pub bytes: Vec<u8>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct PartSize {
    pub role: String,
    pub bytes: usize,
}

#[derive(Clone, Serialize, Deserialize)]
pub struct Prepared {
    pub report_id: String,
    pub source_format: String,
    pub signature: String,
    pub parts: Vec<PartSize>,
    #[serde(default)]
    pub manifest: Value,
    pub bundle_size: usize,
    pub bundle_sha256: Option<String>,
    claim_secret: String,
}

pub fn hash(bytes: &[u8]) -> String {
    Sha256::digest(bytes)
        .iter()
        .map(|b| format!("{b:02x}"))
        .collect()
}

fn valid_id(id: &str) -> bool {
    let digits = if id.len() == 17 {
        id.strip_prefix('f').unwrap_or("")
    } else {
        id
    };
    digits.len() == 16
        && digits
            .bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
}

/// Native formats identify their authoring app; exchange formats and shared `.prt` do not.
fn source_app(source_format: &str) -> &'static str {
    use dutchman_core::Format;
    let format = Format::ALL
        .into_iter()
        .find(|format| {
            format.id().eq_ignore_ascii_case(source_format)
                || format.extensions().iter().any(|extension| {
                    !matches!(*extension, "prt" | "prt.N")
                        && extension.eq_ignore_ascii_case(source_format)
                })
        })
        .or_else(|| Format::from_codec_id(source_format));
    match format {
        None | Some(Format::Step | Format::Iges | Format::Acis | Format::UnclassifiedPart) => {
            "unknown"
        }
        Some(format) => format.family(),
    }
}

impl Prepared {
    /// Reuses the diagnostic file id. No native design file is opened here.
    pub fn new(
        id: &str,
        format: &str,
        signature: &str,
        source: Option<&dyn BundleSource>,
        folder: &Path,
    ) -> Result<Self, String> {
        if !valid_id(id)
            || format.is_empty()
            || format.len() > 64
            || !format
                .bytes()
                .all(|b| b.is_ascii_lowercase() || b.is_ascii_digit() || b"._-".contains(&b))
            || signature.len() > 300
            || !signature.bytes().all(|b| (32..=126).contains(&b))
        {
            return Err("Report metadata is not supported; prepare the report again.".into());
        }
        std::fs::create_dir_all(folder).map_err(|e| e.to_string())?;
        let mut secret = [0u8; 32];
        getrandom::fill(&mut secret).map_err(|e| e.to_string())?;
        let mut prepared = Self {
            report_id: id.into(),
            source_format: format.into(),
            signature: signature.into(),
            parts: Vec::new(),
            manifest: json!([]),
            bundle_size: 0,
            bundle_sha256: None,
            claim_secret: base64url(&secret),
        };
        if let Some(source) = source {
            let parts = source.parts()?;
            if parts
                .iter()
                .any(|p| p.role.len() > 80 || !p.role.bytes().all(|b| (32..=126).contains(&b)))
                || parts.len() > 64
                || parts
                    .iter()
                    .try_fold(0usize, |n, p| n.checked_add(p.bytes.len()))
                    .is_none_or(|n| n > 128 * 1024 * 1024)
            {
                return Err("The bundle is too large; send it with the private-send card.".into());
            }
            // A single payload is a directly replayable gzip CADIR document. Keep role
            // boundaries explicit in a container when a provider needs multiple payloads.
            let mut gzip =
                flate2::write::GzEncoder::new(Vec::new(), flate2::Compression::default());
            if let [part] = parts.as_slice() {
                gzip.write_all(&part.bytes).map_err(|e| e.to_string())?;
            } else {
                let content: Vec<Value> = parts
                    .iter()
                    .map(|p| json!({"role": p.role, "bytes_base64url": base64url(&p.bytes)}))
                    .collect();
                serde_json::to_writer(&mut gzip, &json!({"schema": 1, "parts": content}))
                    .map_err(|e| e.to_string())?;
            }
            let bytes = gzip.finish().map_err(|e| e.to_string())?;
            prepared.parts = parts
                .iter()
                .map(|p| PartSize {
                    role: p.role.clone(),
                    bytes: p.bytes.len(),
                })
                .collect();
            prepared.manifest = source.manifest();
            prepared.bundle_size = bytes.len();
            prepared.bundle_sha256 = Some(hash(&bytes));
            private_write(&folder.join("bundle.json.gz"), &bytes)?;
        }
        private_write(
            &folder.join("prepared.json"),
            &serde_json::to_vec(&prepared).map_err(|e| e.to_string())?,
        )?;
        Ok(prepared)
    }

    pub fn load(folder: &Path) -> Result<Self, String> {
        let bytes = bounded_read(&folder.join("prepared.json"), 1024 * 1024)?;
        serde_json::from_slice(&bytes).map_err(|e| e.to_string())
    }

    /// Safe for MCP: sizes and roles only, never geometry or the claim secret.
    pub fn preview(&self) -> Value {
        json!({"schema": SCHEMA, "ok": true, "report_id": self.report_id, "source_format": self.source_format, "signature": self.signature, "parts": self.parts, "manifest": self.manifest, "bundle_sendable": self.can_send_bundle(), "request_size": self.request_size("bundle", false), "request_limit": MAX_REQUEST, "bundle_limit": MAX_BUNDLE, "private_send": crate::json::DISCORD_URL, "bundle_size": self.bundle_size, "bundle_available": self.bundle_sha256.is_some(), "summary_size": self.metadata("summary", false).to_string().len(), "metadata": self.metadata("summary", false), "default_choice": if self.bundle_sha256.is_some() { "bundle" } else { "summary" }, "public_test": false, "summary": if self.bundle_sha256.is_some() && !self.can_send_bundle() { SIZE_NOTICE } else if self.bundle_sha256.is_some() { "Review the bundle parts and sizes. Bundles contain private geometry." } else { "No bundle is available. Choose summary or use the private-send card." }})
    }

    /// The exact bounded envelope, without the private secret or local paths.
    pub fn metadata(&self, choice: &str, public_test: bool) -> Value {
        let mut report = json!({"schema": 1, "report_id": self.report_id, "dutchman_version": crate::BUILD_VERSION, "os": std::env::consts::OS, "source_format": self.source_format, "source_app": source_app(&self.source_format), "signature": self.signature, "claim_hash": hash(self.claim_secret.as_bytes()), "consent": {"choice": choice, "text_version": 1, "public_test": public_test}});
        if choice == "bundle" {
            if let Some(map) = report.as_object_mut() {
                map.insert("bundle_size".into(), json!(self.bundle_size));
                map.insert("bundle_sha256".into(), json!(self.bundle_sha256));
            }
        }
        report
    }

    /// The exact body size for this consent choice, without opening or exposing geometry.
    pub fn request_size(&self, choice: &str, public_test: bool) -> Option<usize> {
        let metadata = serde_json::to_vec(&self.metadata(choice, public_test)).ok()?;
        multipart_size(
            metadata.len(),
            (choice == "bundle").then_some(self.bundle_size),
        )
    }

    /// Used by both desktop consent and anonymous previews before offering Send.
    pub fn can_send_bundle(&self) -> bool {
        self.bundle_sha256.is_some()
            && self.bundle_size <= MAX_BUNDLE
            && [false, true].into_iter().all(|permission| {
                self.request_size("bundle", permission)
                    .is_some_and(|size| size <= MAX_REQUEST)
            })
    }

    pub fn claim(&self) -> String {
        let digest =
            Sha256::digest(format!("claim-code:{}", hash(self.claim_secret.as_bytes())).as_bytes());
        let alphabet = b"ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
        let mut code = String::new();
        let mut buffer = 0u32;
        let mut bits = 0;
        for byte in digest.iter().take(7) {
            buffer = (buffer << 8) | u32::from(*byte);
            bits += 8;
            while bits >= 5 && code.len() < 10 {
                bits -= 5;
                if let Some(c) = alphabet.get(((buffer >> bits) & 31) as usize) {
                    code.push(char::from(*c));
                }
            }
        }
        format!("claim {}-{code}", self.report_id)
    }
}

/// One framing definition serves size previews and the actual request body.
fn multipart_framing(boundary: &str) -> (String, String, String) {
    (format!("--{boundary}\r\nContent-Disposition: form-data; name=\"report\"\r\nContent-Type: application/json\r\n\r\n"),
     format!("\r\n--{boundary}\r\nContent-Disposition: form-data; name=\"bundle\"; filename=\"repro.gz\"\r\nContent-Type: application/gzip\r\n\r\n"),
     format!("\r\n--{boundary}--\r\n"))
}

fn multipart_size(metadata: usize, bundle: Option<usize>) -> Option<usize> {
    let (header, separator, tail) = multipart_framing(SIZE_BOUNDARY);
    let size = header
        .len()
        .checked_add(metadata)?
        .checked_add(tail.len())?;
    match bundle {
        Some(bytes) => size.checked_add(separator.len())?.checked_add(bytes),
        None => Some(size),
    }
}

fn base64url(bytes: &[u8]) -> String {
    use base64::Engine;
    base64::engine::general_purpose::URL_SAFE_NO_PAD.encode(bytes)
}

pub(crate) fn private_write(path: &Path, bytes: &[u8]) -> Result<(), String> {
    let mut options = std::fs::OpenOptions::new();
    options.write(true).create_new(true);
    #[cfg(unix)]
    {
        use std::os::unix::fs::OpenOptionsExt;
        options.mode(0o600);
    }
    options
        .open(path)
        .and_then(|mut f| f.write_all(bytes))
        .map_err(|e| format!("Cannot keep the local report: {e}"))
}

pub(crate) fn bounded_read(path: &Path, cap: usize) -> Result<Vec<u8>, String> {
    let mut bytes = Vec::new();
    std::fs::File::open(path)
        .and_then(|f| f.take(cap as u64 + 1).read_to_end(&mut bytes))
        .map_err(|e| e.to_string())?;
    if bytes.len() > cap {
        return Err("The local report exceeds its size limit.".into());
    }
    Ok(bytes)
}

/// Where a release build sends a report.
const DEFAULT_ENDPOINT: &str = "https://dutchman-reports.dutchman-cad.workers.dev/api/reports";

/// Where reports go: `DUTCHMAN_REPORT_ENDPOINT` at build time, else the service in a release
/// build. A debug build has no default, so tests and development never reach the service.
pub fn endpoint() -> Option<String> {
    (!cfg!(debug_assertions))
        .then(|| option_env!("DUTCHMAN_REPORT_ENDPOINT").unwrap_or(DEFAULT_ENDPOINT))
        .map(str::to_owned)
}

/// Called only after a click or an explicit yes. Nothing schedules a later resend.
pub fn submit(
    prepared: &Prepared,
    folder: &Path,
    choice: &str,
    public_test: bool,
    explicit_yes: bool,
    endpoint: Option<&str>,
) -> Result<Value, String> {
    if !explicit_yes {
        return Err("Ask the user for an explicit yes before sending this report.".into());
    }
    if !matches!(choice, "bundle" | "summary") {
        return Err("Choose bundle or summary; whole files use the private-send card.".into());
    }
    if choice == "bundle" && !prepared.can_send_bundle() {
        return Err(SIZE_NOTICE.into());
    }
    let bundle = if choice == "bundle" {
        let bytes = bounded_read(&folder.join("bundle.json.gz"), MAX_BUNDLE)?;
        if prepared.bundle_sha256.as_deref() != Some(hash(&bytes).as_str())
            || prepared.bundle_size != bytes.len()
        {
            return Err("The bundle changed; prepare and review it again.".into());
        }
        Some(bytes)
    } else {
        None
    };
    let report = prepared.metadata(choice, public_test);
    let metadata = serde_json::to_vec(&report).map_err(|e| e.to_string())?;
    if metadata.len() > MAX_REPORT {
        return Err("Report metadata exceeds 16 KiB.".into());
    }
    let mut random = [0; 16];
    getrandom::fill(&mut random).map_err(|e| e.to_string())?;
    let boundary = hash(&random);
    let (header, separator, tail) = multipart_framing(&boundary);
    let mut body = header.into_bytes();
    body.extend_from_slice(&metadata);
    if let Some(bytes) = bundle {
        body.extend_from_slice(separator.as_bytes());
        body.extend(bytes);
    }
    body.extend_from_slice(tail.as_bytes());
    if body.len() > MAX_REQUEST {
        return Err(SIZE_NOTICE.into());
    }
    // Keep consent per report, and never reuse an id for different bytes after an attempt.
    let saved = folder.join("submission.json");
    if saved.exists() {
        if bounded_read(&saved, MAX_REPORT)? != metadata {
            return Err(
                "This report already has a saved consent choice. Use the same choice to retry."
                    .into(),
            );
        }
    } else {
        private_write(&saved, &metadata)?;
    }
    let mut rate_limited = false;
    if let Some(endpoint) = endpoint {
        let url = url::Url::parse(endpoint).map_err(|e| e.to_string())?;
        if cfg!(debug_assertions)
            && !matches!(url.host_str(), Some("127.0.0.1" | "localhost" | "[::1]"))
        {
            return Err("Debug builds send reports only to a local test service.".into());
        }
        if url.scheme() != "https"
            && !(url.scheme() == "http"
                && matches!(url.host_str(), Some("127.0.0.1" | "localhost" | "[::1]")))
        {
            return Err("Report sending requires HTTPS.".into());
        }
        let agent = ureq::AgentBuilder::new()
            .timeout(Duration::from_secs(8))
            .redirects(0)
            .build();
        for attempt in 0..2 {
            match agent
                .post(endpoint)
                .set(
                    "Content-Type",
                    &format!("multipart/form-data; boundary={boundary}"),
                )
                .send_bytes(&body)
            {
                Ok(response) => {
                    let status = response.status();
                    let mut bytes = Vec::new();
                    let read = response
                        .into_reader()
                        .take(MAX_REPORT as u64 + 1)
                        .read_to_end(&mut bytes);
                    if read.is_err() {
                        if attempt == 0 {
                            std::thread::sleep(Duration::from_millis(250));
                        }
                        continue;
                    }
                    if bytes.len() <= MAX_REPORT {
                        if let Ok(receipt) = serde_json::from_slice::<Value>(&bytes) {
                            if matches!(status, 200 | 201)
                                && receipt.get("report_id") == Some(&json!(prepared.report_id))
                                && receipt.get("received").and_then(Value::as_u64).is_some()
                            {
                                let receipt_path = folder.join("receipt.json");
                                if !receipt_path.exists() {
                                    private_write(&receipt_path, &bytes)?;
                                }
                                return Ok(
                                    json!({"schema": SCHEMA, "ok": true, "sent": true, "report_id": prepared.report_id, "received": receipt.get("received")}),
                                );
                            }
                        }
                    }
                    break;
                }
                Err(ureq::Error::Status(status, _)) => {
                    rate_limited = status == 429;
                    if status != 429 && status < 500 {
                        break;
                    }
                }
                Err(ureq::Error::Transport(_)) => {}
            }
            if attempt == 0 {
                std::thread::sleep(Duration::from_millis(250));
            }
        }
    }
    Ok(
        json!({"schema": SCHEMA, "ok": false, "sent": false, "report_id": prepared.report_id, "summary": if rate_limited { "It did not go through. Try again tomorrow. Your report is kept locally." } else { "It did not go through. Your report is kept locally. Retry with a click, use the private-send card, or share only the anonymous summary on GitHub." }, "local_folder": folder, "bundle": prepared.bundle_sha256.as_ref().map(|_| folder.join("bundle.json.gz")), "github": crate::issue::NEW_ISSUE, "private_send": crate::json::DISCORD_URL}),
    )
}

/// Compare locally against release metadata; no per-report network request.
pub fn fixed_notice(ids: &[String], fixes: &[String]) -> Option<String> {
    ids.iter()
        .find(|id| fixes.contains(&hash(id.as_bytes())))
        .map(|id| {
            format!(
                "This update fixes a problem you reported ({}).",
                id.chars()
                    .rev()
                    .take(4)
                    .collect::<String>()
                    .chars()
                    .rev()
                    .collect::<String>()
                    .to_uppercase()
            )
        })
}

pub fn local_folder(out: &Path, id: &str) -> PathBuf {
    out.join("reports").join(id)
}

#[cfg(test)]
mod tests;
