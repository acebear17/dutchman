//! Fixed, name-free log locations and retention for automatically placed logs.

use std::collections::BTreeMap;
use std::io::{BufRead, Read};
use std::path::{Path, PathBuf};

/// The platform's diagnostic folder. Resolving it does not create it.
pub fn default_folder() -> Result<PathBuf, String> {
    let home = || {
        std::env::var_os("HOME")
            .filter(|value| !value.is_empty())
            .map(PathBuf::from)
            .ok_or_else(|| "cannot find the home folder; use --diagnostics PATH".to_owned())
    };
    if cfg!(windows) {
        std::env::var_os("LOCALAPPDATA")
            .filter(|value| !value.is_empty())
            .map(|base| PathBuf::from(base).join("Dutchman").join("diagnostics"))
            .ok_or_else(|| "cannot find LOCALAPPDATA; use --diagnostics PATH".to_owned())
    } else if cfg!(target_os = "macos") {
        Ok(home()?.join("Library/Logs/Dutchman"))
    } else {
        let base = std::env::var_os("XDG_STATE_HOME")
            .map(PathBuf::from)
            .filter(|path| path.is_absolute())
            .map_or_else(|| home().map(|path| path.join(".local/state")), Ok)?;
        Ok(base.join("dutchman/diagnostics"))
    }
}

/// Create a uniquely named log at UTC start time and retain the newest [`KEEP_LOGS`] logs.
pub fn new_default_log() -> Result<PathBuf, String> {
    new_log_in(&default_folder()?)
}

/// Like [`new_default_log`], in `folder` rather than the platform's diagnostic folder.
pub fn new_log_in(folder: &Path) -> Result<PathBuf, String> {
    let seconds = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_err(|err| format!("cannot read UTC start time: {err}; use --diagnostics PATH"))?
        .as_secs();
    let stamp =
        utc_timestamp(seconds).ok_or("cannot format UTC start time; use --diagnostics PATH")?;
    create_log(folder, &stamp)
}

fn utc_timestamp(seconds: u64) -> Option<String> {
    // Limit the calendar walk and keep the four-digit year used by retention.
    if seconds > 253_402_300_799 {
        return None;
    }
    let mut days = seconds / 86_400;
    let mut year = 1970;
    let leap = |year| year % 4 == 0 && (year % 100 != 0 || year % 400 == 0);
    loop {
        let length = if leap(year) { 366 } else { 365 };
        if days < length {
            break;
        }
        days -= length;
        year += 1;
    }
    let mut month = 1;
    for length in [
        31,
        if leap(year) { 29 } else { 28 },
        31,
        30,
        31,
        30,
        31,
        31,
        30,
        31,
        30,
        31,
    ] {
        if days < length {
            break;
        }
        days -= length;
        month += 1;
    }
    let day = days + 1;
    let hour = seconds % 86_400 / 3_600;
    let minute = seconds % 3_600 / 60;
    let second = seconds % 60;
    Some(format!(
        "{year:04}-{month:02}-{day:02}_{hour:02}{minute:02}{second:02}"
    ))
}

fn create_log(folder: &Path, stamp: &str) -> Result<PathBuf, String> {
    std::fs::create_dir_all(folder).map_err(|err| {
        format!(
            "cannot create diagnostic folder {}: {err}",
            folder.display()
        )
    })?;
    let latest = logs(folder)
        .into_iter()
        .filter_map(|path| {
            let name = path.file_stem()?.to_str()?.split("_dutchman-").next()?;
            if name.get(..17)? != stamp {
                return None;
            }
            name.get(18..)
                .map_or(Some(0_u64), |suffix| suffix.parse().ok())
        })
        .max();
    let first = match latest {
        Some(counter) => counter
            .checked_add(1)
            .ok_or("cannot choose a unique diagnostic log name; use --diagnostics PATH")?,
        None => 0,
    };
    for offset in 0..10_000 {
        let counter = first
            .checked_add(offset)
            .ok_or("cannot choose a unique diagnostic log name; use --diagnostics PATH")?;
        let name = if counter == 0 {
            format!("{stamp}_dutchman-{}_running.jsonl", crate::BUILD_VERSION)
        } else {
            format!(
                "{stamp}-{counter}_dutchman-{}_running.jsonl",
                crate::BUILD_VERSION
            )
        };
        let path = folder.join(name);
        match std::fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&path)
        {
            Ok(_) => {
                retain(folder, &path)?;
                return Ok(path);
            }
            Err(err) if err.kind() == std::io::ErrorKind::AlreadyExists => continue,
            Err(err) => {
                return Err(format!(
                    "cannot create diagnostic log {}: {err}",
                    path.display()
                ))
            }
        }
    }
    Err("cannot choose a unique diagnostic log name; use --diagnostics PATH".into())
}

/// Finish an automatically placed run after every writer (including workers) has closed.
/// A failed rename leaves the running path usable and never changes the conversion result.
pub fn finish_default_log(path: &Path, result: &str) -> PathBuf {
    let Some(name) = path.file_name().and_then(|n| n.to_str()) else {
        return path.into();
    };
    if !log_name(name) || !matches!(result, "converted" | "failed" | "stopped") {
        return path.into();
    }
    let Some(prefix) = name.strip_suffix("_running.jsonl") else {
        return path.into();
    };
    let target = path.with_file_name(format!("{prefix}_{result}.jsonl"));
    if !target.exists() && std::fs::rename(path, &target).is_ok() {
        target
    } else {
        path.into()
    }
}

fn log_name(name: &str) -> bool {
    let Some(stem) = name.strip_suffix(".jsonl") else {
        return false;
    };
    let (stem, result) = stem
        .split_once("_dutchman-")
        .map_or((stem, None), |(stamp, rest)| (stamp, Some(rest)));
    if let Some(rest) = result {
        let Some((version, outcome)) = rest.rsplit_once('_') else {
            return false;
        };
        if version.is_empty()
            || !version
                .bytes()
                .all(|b| b.is_ascii_alphanumeric() || matches!(b, b'.' | b'-' | b'+'))
            || !matches!(outcome, "running" | "converted" | "failed" | "stopped")
        {
            return false;
        }
    }
    let Some(date) = stem.get(..17) else {
        return false;
    };
    if !date.bytes().enumerate().all(|(i, byte)| match i {
        4 | 7 => byte == b'-',
        10 => byte == b'_',
        _ => byte.is_ascii_digit(),
    }) {
        return false;
    }
    let suffix = stem.get(17..).unwrap_or_default();
    suffix.is_empty()
        || suffix
            .strip_prefix('-')
            .is_some_and(|s| !s.is_empty() && s.bytes().all(|b| b.is_ascii_digit()))
}

fn logs(folder: &Path) -> Vec<PathBuf> {
    let mut logs: Vec<_> = std::fs::read_dir(folder)
        .into_iter()
        .flatten()
        .filter_map(Result::ok)
        .filter(|entry| entry.file_type().is_ok_and(|kind| kind.is_file()))
        .filter(|entry| entry.file_name().to_str().is_some_and(log_name))
        .map(|entry| entry.path())
        .collect();
    logs.sort_by_cached_key(|path| {
        let name = path
            .file_stem()
            .and_then(|name| name.to_str())
            .unwrap_or_default();
        let stamp = name.get(..17).unwrap_or_default().to_owned();
        let counter = name
            .split("_dutchman-")
            .next()
            .unwrap_or_default()
            .get(18..)
            .and_then(|s| s.parse::<u64>().ok())
            .unwrap_or(0);
        (
            std::fs::metadata(path).and_then(|m| m.modified()).ok(),
            stamp,
            counter,
        )
    });
    logs.reverse();
    logs
}

/// How many automatically placed logs are kept. The desktop app names a run's log in the prompt it
/// copies for an AI assistant, so a log has to outlive a good number of later runs.
pub const KEEP_LOGS: usize = 50;

fn retain(folder: &Path, current: &Path) -> Result<(), String> {
    // Keep the new file even on a filesystem with coarse modification timestamps.
    let older: Vec<_> = logs(folder)
        .into_iter()
        .filter(|path| path != current)
        .collect();
    for path in older.into_iter().skip(KEEP_LOGS - 1) {
        std::fs::remove_file(&path)
            .map_err(|err| format!("cannot remove old diagnostic log {}: {err}", path.display()))?;
    }
    Ok(())
}

/// Newest default log with an unfinished conversion, for the app's launch notice.
pub fn unfinished_default_log() -> Option<PathBuf> {
    unfinished_log_in(&default_folder().ok()?)
}

/// Newest log in `folder` with an unfinished conversion.
pub fn unfinished_log_in(folder: &Path) -> Option<PathBuf> {
    let path = logs(folder).into_iter().next()?;
    unfinished(&path).then_some(path)
}

fn unfinished(path: &Path) -> bool {
    // A completed run can contain no conversion rows (for example a planning refusal).
    // Final names are written only after all writers have returned.
    if path
        .file_stem()
        .and_then(|name| name.to_str())
        .is_some_and(|name| {
            name.contains("_dutchman-")
                && ["_converted", "_failed", "_stopped"]
                    .iter()
                    .any(|result| name.ends_with(*result))
        })
    {
        return false;
    }
    let Ok(file) = std::fs::File::open(path) else {
        return false;
    };
    let mut active = BTreeMap::<String, u64>::new();
    let mut ended = false;
    let mut reader = std::io::BufReader::new(file);
    loop {
        // A bounded start record can list 10,000 members. Refuse a tampered oversized
        // line rather than allocating without limit while opening the desktop app.
        let mut line = String::new();
        match reader.by_ref().take(4 << 20).read_line(&mut line) {
            Ok(0) => break,
            Ok(_) if line.ends_with('\n') => {}
            _ => return true,
        }
        let Ok(record) = serde_json::from_str::<serde_json::Value>(&line) else {
            return true;
        };
        let Some(id) = record.get("file").and_then(serde_json::Value::as_str) else {
            continue;
        };
        match record.get("type").and_then(serde_json::Value::as_str) {
            Some("start") => {
                if active.len() >= 100_000 && !active.contains_key(id) {
                    return true;
                }
                *active.entry(id.to_owned()).or_default() += 1;
            }
            Some("end") => {
                ended = true;
                if let Some(count) = active.get_mut(id) {
                    *count = count.saturating_sub(1);
                    if *count == 0 {
                        active.remove(id);
                    }
                }
            }
            _ => {}
        }
    }
    !ended || active.values().any(|count| *count > 0)
}

#[cfg(test)]
#[allow(clippy::unwrap_used)]
mod tests {
    use super::*;

    #[test]
    fn utc_names_cover_epoch_leap_days_and_year_boundaries() {
        for (seconds, stamp) in [
            (0, "1970-01-01_000000"),
            (951_782_400, "2000-02-29_000000"),
            (1_704_067_199, "2023-12-31_235959"),
            (1_704_067_200, "2024-01-01_000000"),
            (253_402_300_799, "9999-12-31_235959"),
        ] {
            assert_eq!(utc_timestamp(seconds).as_deref(), Some(stamp));
            assert!(log_name(&format!("{stamp}.jsonl")));
        }
        assert!(utc_timestamp(u64::MAX).is_none());
    }

    #[test]
    fn unique_names_retention_and_unrelated_files() {
        let dir = tempfile::tempdir().unwrap();
        std::fs::write(dir.path().join("notes.jsonl"), "keep").unwrap();
        std::fs::create_dir(dir.path().join("2026-10-29_201500-99.jsonl")).unwrap();
        let mut paths = Vec::new();
        for _ in 0..KEEP_LOGS + 2 {
            paths.push(create_log(dir.path(), "2026-10-29_201500").unwrap());
        }
        assert_eq!(logs(dir.path()).len(), KEEP_LOGS);
        let unique: std::collections::BTreeSet<_> = paths.iter().collect();
        assert_eq!(unique.len(), paths.len());
        assert!(paths.last().unwrap().is_file());
        assert!(paths.iter().take(2).all(|path| !path.exists()));
        assert!(paths.iter().skip(2).all(|path| path.is_file()));
        assert_eq!(
            std::fs::read_to_string(dir.path().join("notes.jsonl")).unwrap(),
            "keep"
        );
        assert!(dir.path().join("2026-10-29_201500-99.jsonl").is_dir());
        for name in [
            "report.jsonl",
            "2026-10-29_201500-private.jsonl",
            "2026-10-29_201500.jsonl.bak",
        ] {
            assert!(!log_name(name));
        }
    }

    #[test]
    fn results_rename_only_closed_default_logs_and_keep_crash_names() {
        let dir = tempfile::tempdir().unwrap();
        for result in ["converted", "failed", "stopped"] {
            let running = create_log(dir.path(), "2026-11-02_163710").unwrap();
            let writer = std::fs::OpenOptions::new()
                .append(true)
                .open(&running)
                .unwrap();
            drop(writer);
            let finished = finish_default_log(&running, result);
            assert_ne!(finished, running);
            assert!(finished
                .file_name()
                .unwrap()
                .to_str()
                .unwrap()
                .ends_with(&format!("_{result}.jsonl")));
            assert!(log_name(finished.file_name().unwrap().to_str().unwrap()));
            assert!(!running.exists());
            assert!(!unfinished(&finished));
        }
        let running = create_log(dir.path(), "2026-11-02_163710").unwrap();
        assert!(unfinished(&running));
        assert!(logs(dir.path()).contains(&running));
        let target = running.with_file_name(
            running
                .file_name()
                .unwrap()
                .to_str()
                .unwrap()
                .replace("_running", "_failed"),
        );
        std::fs::create_dir(&target).unwrap();
        assert_eq!(finish_default_log(&running, "failed"), running);
        assert!(running.is_file());
        let explicit = dir.path().join("chosen.jsonl");
        std::fs::write(&explicit, "").unwrap();
        assert_eq!(finish_default_log(&explicit, "converted"), explicit);
    }

    #[test]
    fn retention_includes_legacy_and_all_result_names() {
        let dir = tempfile::tempdir().unwrap();
        let legacy = dir.path().join("2026-10-29_201500.jsonl");
        std::fs::write(&legacy, "").unwrap();
        let legacy_counter = dir.path().join("2026-10-29_201500-1.jsonl");
        std::fs::write(&legacy_counter, "").unwrap();
        for result in ["converted", "failed", "stopped", "running"]
            .into_iter()
            .cycle()
            .take(KEEP_LOGS + 2)
        {
            let path = create_log(dir.path(), "2026-11-02_163710").unwrap();
            if result != "running" {
                finish_default_log(&path, result);
            }
        }
        assert_eq!(logs(dir.path()).len(), KEEP_LOGS);
        assert!(!legacy.exists());
        assert!(!legacy_counter.exists());
    }

    #[test]
    fn running_log_is_found_at_launch_in_an_isolated_home() {
        if std::env::var_os("DUTCHMAN_RUNLOG_RECOVERY_CHILD").is_some() {
            let folder = default_folder().unwrap();
            let path = create_log(&folder, "2026-11-02_163710").unwrap();
            std::fs::write(&path, "{\"type\":\"start\",\"file\":\"f1\"}\n").unwrap();
            assert_eq!(unfinished_default_log(), Some(path));
            return;
        }
        let dir = tempfile::tempdir().unwrap();
        let status = std::process::Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "diagnostics::location::tests::running_log_is_found_at_launch_in_an_isolated_home",
            ])
            .env("DUTCHMAN_RUNLOG_RECOVERY_CHILD", "1")
            .env("HOME", dir.path())
            .env("LOCALAPPDATA", dir.path())
            .env("XDG_STATE_HOME", dir.path())
            .status()
            .unwrap();
        assert!(status.success());
    }

    #[test]
    fn recovery_tracks_all_conversions_and_truncated_lines() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("log");
        std::fs::write(&path, "").unwrap();
        assert!(unfinished(&path));
        std::fs::write(&path, "{\"type\":\"start\",\"file\":\"f1\"}\n{\"type\":\"start\",\"file\":\"f2\"}\n{\"type\":\"end\",\"file\":\"f2\"}\n").unwrap();
        assert!(unfinished(&path));
        use std::io::Write;
        let mut file = std::fs::OpenOptions::new()
            .append(true)
            .open(&path)
            .unwrap();
        writeln!(file, "{{\"type\":\"end\",\"file\":\"f1\"}}").unwrap();
        assert!(!unfinished(&path));
        write!(file, "{{\"type\":").unwrap();
        assert!(unfinished(&path));
    }
}
