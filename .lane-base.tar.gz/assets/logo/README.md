# Dutchman logo

Dutchman's own artwork, licensed with the rest of this repository under the
[Apache License, Version 2.0](../../LICENSE).

The mark is a single-masted ship. Its square sail is split at the mast: the left half is solid,
the closed native file; the right half is a wireframe, the open model Dutchman produces. The
lantern at the masthead is the one warm light.

| File | Use |
|---|---|
| `dutchman-mark.svg` | The mark on light grounds. |
| `dutchman-mark-night.svg` | The mark on dark grounds. |
| `dutchman-mark-mono.svg` | The mark in one ink, where colour is not available. |
| `dutchman-lockup.svg` | Mark and name on light grounds. |
| `dutchman-lockup-night.svg` | Mark and name on dark grounds. |
| `dutchman-app-icon.svg` | The macOS app icon: the mark on a white rounded square (824 px, corner radius 185) on Apple's 1024 grid, with a hairline edge and a soft shadow below. It is the app bundle's icon and, on macOS, the Dock icon while the app runs. `cargo run -p dutchman-gui --example icns -- crates/dutchman-gui/assets/Dutchman.icns` renders it into the app's icon file. The app keeps its own copy in `crates/dutchman-gui/assets/`, with the marks; a test checks the copies match. |
| `dutchman-lockup.png`, `dutchman-lockup-night.png` | The lockups rendered at 3× with the name set in Spectral, for places that cannot load the font (GitHub's README view). |

The lockup's name is set in [Spectral](https://github.com/productiontype/Spectral) SemiBold
(SIL Open Font License 1.1). The SVGs name the font and do not embed it; the PNGs were rendered
from them with Spectral installed.

Keep clear space of one hull height (a sixth of the mark's height) on every side. Use the mark at
16 px or larger and the lockup at 120 px wide or larger. Don't recolour, rotate, outline or shadow
the mark, separate the lantern, or place the mark on a photograph.

The Windows installer renders the same app SVG into a multi-size ICO at build time with
`cargo run -p dutchman-gui --example ico -- dist/Dutchman.ico`. The icon is used for its Start
menu shortcut and Installed apps entry; no external artwork is included.
