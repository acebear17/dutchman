//! Bodies a design keeps hidden. Fusion keeps unowned consumed or removed bodies; owned
//! hidden bodies remain parts of the design. A FreeCAD document stores the shape of every step of a
//! PartDesign Body (each Pad and Pocket result, its tool shapes) beside the Body's own shape,
//! and shows only the last; cadmpeg marks the others `visible: false`. They are not parts of
//! the design, so they are left out rather than converted as bodies of their own.

use std::collections::{BTreeMap, BTreeSet};

use serde_json::Value;

use crate::assembly::strings;
#[cfg(test)]
use crate::assembly::NOT_GEOMETRY;
use crate::{Model, Report, Severity};

/// The arenas a body's B-rep is made of. Only rows of these that hidden bodies alone reach are
/// left out: a sketch, a feature or anything else a hidden body names (a sketch's own wire
/// body is hidden, and its sketch is still the history's) is kept.
const BREP: [&str; 15] = [
    "regions",
    "shells",
    "faces",
    "loops",
    "coedges",
    "edges",
    "vertices",
    "points",
    "surfaces",
    "curves",
    "pcurves",
    "procedural_surfaces",
    "procedural_curves",
    "subds",
    "tessellations",
];

/// Fusion keeps consumed tools and removed bodies outside every component's body list.
/// User-hidden component members remain available, even when their visibility cannot be
/// represented separately by a writer's single geometry import.
pub(crate) fn fusion(model: Model, report: &mut Report) -> Model {
    let owned: BTreeSet<_> = model
        .ir
        .model
        .product_definitions
        .iter()
        .flat_map(|definition| definition.bodies.iter().map(|body| body.as_str()))
        .collect();
    let hidden = model
        .ir
        .geometry
        .bodies
        .iter()
        .filter(|body| body.visible == Some(false) && owned.contains(body.id.as_str()))
        .count();
    if hidden > 0 {
        report.push(Severity::Info, "bodies", format!(
            "{hidden} user-hidden Fusion bodies were kept, marked hidden: SolidCraft 0.42 and newer open them hidden; older releases show a part with both shown and hidden bodies whole"
        ));
    }
    // Fusion needs no visibility rewrite when it has no unowned hidden bodies.
    // Avoid expanding all geometry and native records just to discover that.
    // A mixed namespace still follows the existing FreeCAD container handling.
    if model.ir.native.namespace("fcstd").is_none()
        && !model
            .ir
            .geometry
            .bodies
            .iter()
            .any(|body| body.visible == Some(false) && !owned.contains(body.id.as_str()))
    {
        return model;
    }
    match filtered(&model, true) {
        Ok(Some((mut shown, count))) => {
            // Do not later describe a deliberately filtered target as a
            // decoder omission. Truly dangling assignments remain for mapping
            // to diagnose against the decoded model.
            let before: BTreeSet<_> = model
                .ir
                .geometry
                .bodies
                .iter()
                .map(|b| b.id.as_str())
                .chain(model.ir.geometry.faces.iter().map(|f| f.id.as_str()))
                .collect();
            let kept: BTreeSet<_> = shown
                .ir
                .geometry
                .bodies
                .iter()
                .map(|b| b.id.as_str())
                .chain(shown.ir.geometry.faces.iter().map(|f| f.id.as_str()))
                .collect();
            shown.ir.model.appearance_bindings.retain(|binding| {
                use cadmpeg_ir::appearance::AppearanceTarget;
                // A state or instance does not describe this definition's current
                // geometry. Leave its specific refusal to appearance mapping.
                if binding.target.path.is_some() || binding.target.state.is_some() {
                    return true;
                }
                let (kind,id) = match &binding.target.entity {
                    AppearanceTarget::Body(id) => ("body",id.as_str()),
                    AppearanceTarget::Face(id) => ("face",id.as_str()),
                    _ => return true,
                };
                if before.contains(id) && !kept.contains(id) {
                    report.push_appearance(crate::AppearanceLoss::Other,format!(
                        "Appearance binding {} to {kind} {id} is left out: its target belongs only to consumed or removed Fusion geometry",binding.id));
                    false
                } else { true }
            });
            report.push(Severity::Info, "bodies", format!(
                "{count} bodies Fusion keeps only as consumed tools or removed bodies were not converted"
            ));
            shown
        }
        Ok(None) => model,
        Err(why) => {
            report.push(
                Severity::Degraded,
                "bodies",
                format!("consumed or removed Fusion bodies converted too, as {why}"),
            );
            model
        }
    }
}

/// `model` without its hidden bodies and the geometry only they reach, with how many were
/// left out; `None` when visibility is unchanged, or nothing but hidden bodies remain
/// (then it converts as stored). Ancestor visibility is propagated to occurrences; history,
/// structure and parameters are kept.
pub(crate) fn shown(model: &Model) -> Result<Option<(Model, usize)>, String> {
    filtered(model, false)
}

fn filtered(model: &Model, fusion: bool) -> Result<Option<(Model, usize)>, String> {
    let bodies = &model.ir.geometry.bodies;
    let mut document = serde_json::to_value(&model.ir).map_err(|err| err.to_string())?;
    // FreeCAD hides what a hidden container holds. Other formats say each body's and each
    // occurrence's own visibility, and the assembly writer keeps hidden occurrences hidden.
    let freecad = document.pointer("/native/fcstd").is_some();
    let visibility_changed = freecad && propagate_visibility(&mut document);
    let owned: BTreeSet<&str> = listed(document.pointer("/model/product_definitions"))
        .iter()
        .flat_map(|definition| listed(definition.get("bodies")))
        .filter_map(Value::as_str)
        .collect();
    let hidden_ids = if freecad && !fusion {
        hidden_bodies(&document)
    } else {
        listed(document.pointer("/geometry/bodies"))
            .iter()
            .filter(|body| body.get("visible").and_then(Value::as_bool) == Some(false))
            .filter_map(|body| body.get("id").and_then(Value::as_str))
            .filter(|id| !fusion || !owned.contains(id))
            .map(str::to_owned)
            .collect()
    };
    let hidden = hidden_ids.len();
    if (hidden == 0 && !visibility_changed) || (!fusion && hidden == bodies.len()) {
        return Ok(None);
    }
    crate::input_edges::preserve(&mut document, &model.ir);
    let mut geometry_home = document
        .get_mut("geometry")
        .ok_or("the model is malformed")?
        .take();
    let wire = geometry_home
        .as_object_mut()
        .ok_or("the model is malformed")?;
    let tessellations = listed(document.pointer("/model/tessellations"));
    let shown_rows: Vec<&Value> = listed(wire.get("bodies"))
        .iter()
        .filter(|body| {
            !hidden_ids.contains(body.get("id").and_then(Value::as_str).unwrap_or_default())
        })
        .collect();
    let geometry: BTreeSet<&str> = wire
        .iter()
        .filter(|(arena, _)| BREP.contains(&arena.as_str()))
        .flat_map(|(_, rows)| listed(Some(rows)))
        .chain(tessellations)
        .filter_map(|row| row.get("id").and_then(Value::as_str))
        .collect();
    let rows: std::collections::BTreeMap<&str, &Value> = wire
        .values()
        .flat_map(|rows| listed(Some(rows)))
        .chain(tessellations)
        .filter_map(|row| Some((row.get("id").and_then(Value::as_str)?, row)))
        .collect();
    // A procedural construction names the curve or surface it constructs, not the other way
    // round: reaching the carrier reaches its construction (a trimmed curve's basis, say).
    let mut constructions: std::collections::BTreeMap<&str, Vec<&Value>> =
        std::collections::BTreeMap::new();
    for (arena, field) in [
        ("procedural_curves", "curve"),
        ("procedural_surfaces", "surface"),
    ] {
        for row in listed(wire.get(arena)) {
            if let Some(carrier) = row.get(field).and_then(Value::as_str) {
                constructions.entry(carrier).or_default().push(row);
            }
        }
    }
    let mut children: BTreeMap<&str, Vec<&Value>> = BTreeMap::new();
    for (arena, key) in [("regions", "body"), ("faces", "shell")] {
        for row in listed(wire.get(arena)) {
            if let Some(parent) = row.get(key).and_then(Value::as_str) {
                children.entry(parent).or_default().push(row);
            }
        }
    }
    // The geometry the shown bodies reach; the rest of the geometry is the hidden bodies'.
    let mut reached: BTreeSet<String> = BTreeSet::new();
    let mut queue: Vec<&Value> = shown_rows;
    while let Some(row) = queue.pop() {
        let mut refs = Vec::new();
        strings(row, &mut refs);
        if let Some(id) = row.get("id").and_then(Value::as_str) {
            for child in children.get(id).into_iter().flatten() {
                if let Some(id) = child.get("id").and_then(Value::as_str) {
                    refs.push(id);
                }
            }
        }
        for reference in refs {
            if geometry.contains(reference) && reached.insert(reference.to_owned()) {
                if let Some(next) = rows.get(reference) {
                    queue.push(next);
                }
                for construction in constructions.get(reference).into_iter().flatten() {
                    if let Some(id) = construction.get("id").and_then(Value::as_str) {
                        if reached.insert(id.to_owned()) {
                            queue.push(construction);
                        }
                    }
                }
            }
        }
    }
    let unreached: BTreeSet<String> = geometry
        .iter()
        .filter(|id| !reached.contains(**id))
        .map(|id| (*id).to_owned())
        .collect();
    for (arena, values) in wire.iter_mut() {
        let Some(values) = values.as_array_mut() else {
            continue;
        };
        values.retain(|row| {
            let id = row.get("id").and_then(Value::as_str).unwrap_or_default();
            if arena == "bodies" {
                !hidden_ids.contains(id)
            } else {
                !unreached.contains(id)
            }
        });
    }
    if let Some(rows) = document
        .pointer_mut("/model/tessellations")
        .and_then(Value::as_array_mut)
    {
        rows.retain(|row| {
            !row.get("id")
                .and_then(Value::as_str)
                .is_some_and(|id| unreached.contains(id))
        });
    }
    if let Some(home) = document.get_mut("geometry") {
        *home = geometry_home;
    }
    // cadmpeg is third-party code; a panic in it is a reason, not a crash.
    let text = document.to_string();
    let ir = std::panic::catch_unwind(|| cadmpeg_ir::CadIr::from_json(&text))
        .map_err(|_| "cadmpeg failed unexpectedly on the shown bodies".to_owned())?
        .map_err(|err| format!("the shown bodies do not stand alone: {err}"))?;
    Ok(Some((
        Model {
            ir,
            fidelity: model.fidelity.clone(),
            name: model.name.clone(),
            source_file: model.source_file.clone(),
            assembly: model.assembly.clone(),
            // The shown bodies are a subset of the file's: restate them.
            source_step: None,
        },
        hidden,
    )))
}

/// A definition used in any shown occurrence remains available. A hidden occurrence hides
/// its descendants, even when their own visibility is explicitly true.
fn hidden_bodies(document: &Value) -> BTreeSet<String> {
    let model = document.get("model").unwrap_or(&Value::Null);
    let mut hidden: BTreeSet<String> = listed(document.pointer("/geometry/bodies"))
        .iter()
        .filter(|body| body.get("visible").and_then(Value::as_bool) == Some(false))
        .filter_map(|body| body.get("id").and_then(Value::as_str).map(str::to_owned))
        .collect();
    let concealed_objects = hidden_objects(document);
    let mut inherited = BTreeSet::new();
    for feature in listed(model.get("features")) {
        if feature
            .get("native_ref")
            .and_then(Value::as_str)
            .is_some_and(|id| concealed_objects.contains(id))
        {
            inherited.extend(
                listed(feature.get("outputs"))
                    .iter()
                    .filter_map(Value::as_str)
                    .map(str::to_owned),
            );
        }
    }
    let occurrences = listed(model.get("occurrences"));
    let concealed = concealed_occurrences(model, &concealed_objects);
    let mut shown_definitions = BTreeSet::new();
    let mut hidden_definitions = BTreeSet::new();
    for occurrence in occurrences {
        let Some(definition) = occurrence
            .pointer("/prototype/definition")
            .and_then(Value::as_str)
        else {
            continue;
        };
        if occurrence
            .get("id")
            .and_then(Value::as_str)
            .is_some_and(|id| concealed.contains(id))
        {
            hidden_definitions.insert(definition);
        } else {
            shown_definitions.insert(definition);
        }
    }
    for definition in listed(model.get("product_definitions")) {
        if definition
            .get("id")
            .and_then(Value::as_str)
            .is_some_and(|id| hidden_definitions.contains(id) && !shown_definitions.contains(id))
        {
            hidden.extend(
                listed(definition.get("bodies"))
                    .iter()
                    .filter_map(Value::as_str)
                    .map(str::to_owned),
            );
        }
    }
    let shown_bodies: BTreeSet<&str> = listed(model.get("product_definitions"))
        .iter()
        .filter(|definition| {
            definition
                .get("id")
                .and_then(Value::as_str)
                .is_some_and(|id| shown_definitions.contains(id))
        })
        .flat_map(|definition| listed(definition.get("bodies")))
        .filter_map(Value::as_str)
        .collect();
    hidden.extend(
        inherited
            .into_iter()
            .filter(|id| !shown_bodies.contains(id.as_str())),
    );
    let bodies: BTreeSet<&str> = listed(document.pointer("/geometry/bodies"))
        .iter()
        .filter_map(|body| body.get("id").and_then(Value::as_str))
        .collect();
    hidden.retain(|id| bodies.contains(id.as_str()));
    hidden
}

fn concealed_occurrences<'a>(
    model: &'a Value,
    concealed_objects: &BTreeSet<&str>,
) -> BTreeSet<&'a str> {
    let occurrences = listed(model.get("occurrences"));
    let mut children: BTreeMap<&str, Vec<&str>> = BTreeMap::new();
    let mut concealed = BTreeSet::new();
    let mut queue = Vec::new();
    for occurrence in occurrences {
        let Some(id) = occurrence.get("id").and_then(Value::as_str) else {
            continue;
        };
        if let Some(parent) = occurrence
            .pointer("/parent/occurrence")
            .and_then(Value::as_str)
        {
            children.entry(parent).or_default().push(id);
        }
        if occurrence.get("visible").and_then(Value::as_bool) == Some(false)
            || occurrence
                .get("native_ref")
                .and_then(Value::as_str)
                .is_some_and(|id| concealed_objects.contains(id))
        {
            queue.push(id);
        }
    }
    while let Some(id) = queue.pop() {
        if concealed.insert(id) {
            queue.extend(children.get(id).into_iter().flatten().copied());
        }
    }
    concealed
}

fn propagate_visibility(document: &mut Value) -> bool {
    let objects = hidden_objects(document);
    let concealed: BTreeSet<String> =
        concealed_occurrences(document.get("model").unwrap_or(&Value::Null), &objects)
            .into_iter()
            .map(str::to_owned)
            .collect();
    let Some(occurrences) = document
        .pointer_mut("/model/occurrences")
        .and_then(Value::as_array_mut)
    else {
        return false;
    };
    let mut changed = false;
    for occurrence in occurrences {
        if occurrence
            .get("id")
            .and_then(Value::as_str)
            .is_some_and(|id| concealed.contains(id))
            && occurrence.get("visible").and_then(Value::as_bool) != Some(false)
        {
            if let Some(fields) = occurrence.as_object_mut() {
                fields.insert("visible".to_owned(), Value::Bool(false));
                changed = true;
            }
        }
    }
    changed
}

/// cadmpeg retains decoded container membership and GUI properties even for a container
/// with no shape. Use those records, never source XML, to propagate visibility to its shapes.
fn hidden_objects(document: &Value) -> BTreeSet<&str> {
    let native = document.pointer("/native/fcstd").unwrap_or(&Value::Null);
    let providers: BTreeMap<&str, &str> = listed(native.get("gui_view_providers"))
        .iter()
        .filter_map(|row| Some((row.get("id")?.as_str()?, row.get("object")?.as_str()?)))
        .collect();
    let mut visibility = BTreeMap::new();
    for (arena, gui) in [("properties", false), ("gui_properties", true)] {
        for property in listed(native.get(arena)) {
            if property.get("name").and_then(Value::as_str) != Some("Visibility")
                || property.get("type_name").and_then(Value::as_str) != Some("App::PropertyBool")
            {
                continue;
            }
            let owner = property.get("owner").and_then(Value::as_str);
            let owner = if gui {
                owner.and_then(|id| providers.get(id).copied())
            } else {
                owner
            };
            let value = listed(property.get("values"))
                .iter()
                .find(|value| value.get("tag").and_then(Value::as_str) == Some("Bool"))
                .and_then(|value| value.pointer("/attributes/value"))
                .and_then(Value::as_str);
            if let (Some(owner), Some(value @ ("true" | "false" | "0" | "1"))) = (owner, value) {
                visibility.insert(owner, matches!(value, "true" | "1"));
            }
        }
    }
    let containers: BTreeSet<&str> = listed(native.get("objects"))
        .iter()
        .filter(|row| {
            matches!(
                row.get("type_name").and_then(Value::as_str),
                Some("PartDesign::Body" | "App::Part" | "App::DocumentObjectGroup")
            )
        })
        .filter_map(|row| row.get("id").and_then(Value::as_str))
        .collect();
    let mut children: BTreeMap<&str, Vec<&str>> = BTreeMap::new();
    for property in listed(native.get("properties")) {
        let Some(owner) = property
            .get("owner")
            .and_then(Value::as_str)
            .filter(|id| containers.contains(id))
        else {
            continue;
        };
        if property.get("name").and_then(Value::as_str) == Some("Group") {
            for link in listed(property.get("links")) {
                if link.get("document").is_none_or(Value::is_null) {
                    if let Some(child) = link.get("object").and_then(Value::as_str) {
                        children.entry(owner).or_default().push(child);
                    }
                }
            }
        }
    }
    let mut hidden = BTreeSet::new();
    let mut queue: Vec<&str> = visibility
        .into_iter()
        .filter_map(|(id, visible)| (!visible).then_some(id))
        .collect();
    while let Some(id) = queue.pop() {
        if hidden.insert(id) {
            queue.extend(children.get(id).into_iter().flatten().copied());
        }
    }
    hidden
}

fn listed(value: Option<&Value>) -> &[Value] {
    value
        .and_then(Value::as_array)
        .map_or(&[][..], Vec::as_slice)
}

#[cfg(test)]
#[allow(clippy::unwrap_used)]
mod tests {
    use std::collections::BTreeMap;
    use std::path::Path;

    use serde_json::json;

    use super::*;
    use crate::{Format, Report};

    #[test]
    fn consumed_geometry_appearance_targets_are_not_reported_as_decoder_omissions() {
        let mut model = two_cubes(Some(false));
        let mut wire = serde_json::to_value(&model.ir).unwrap();
        let body = wire["geometry"]["bodies"][1]["id"].clone();
        let face = wire["geometry"]["faces"]
            .as_array()
            .unwrap()
            .iter()
            .find(|f| f["id"].as_str().unwrap().ends_with("~copy"))
            .unwrap()["id"]
            .clone();
        wire["model"]["appearances"] = json!([{"id": "synthetic:test:appearance#red", "base_color": {"r":1.0,"g":0.0,"b":0.0,"a":1.0}, "properties": {}, "textures": []}]);
        wire["model"]["appearance_bindings"] = json!([
            {"id": "synthetic:test:binding#body", "target": {"entity": {"kind":"body","value":body}}, "appearance": "synthetic:test:appearance#red", "channels": {}},
            {"id": "synthetic:test:binding#face", "target": {"entity": {"kind":"face","value":face}}, "appearance": "synthetic:test:appearance#red", "channels": {}},
            {"id": "synthetic:test:binding#missing", "target": {"entity": {"kind":"face","value":"synthetic:test:face#missing"}}, "appearance": "synthetic:test:appearance#red", "channels": {}}
        ]);
        model.ir = cadmpeg_ir::CadIr::from_json(&wire.to_string()).unwrap();
        let mut report = Report::default();
        let shown = fusion(model, &mut report);
        assert_eq!(shown.ir.geometry.bodies.len(), 1);
        assert_eq!(shown.ir.model.appearance_bindings.len(), 1);
        assert!(shown.ir.model.appearance_bindings[0]
            .id
            .as_str()
            .ends_with("#missing"));
        let notes: Vec<_> = report
            .losses()
            .iter()
            .filter(|l| l.subject == "appearance")
            .collect();
        assert_eq!(notes.len(), 2);
        assert!(notes
            .iter()
            .all(|loss| loss.code.as_deref() == Some("dutchman/appearance.other")));
        assert!(notes.iter().all(|l| l
            .detail
            .ends_with("its target belongs only to consumed or removed Fusion geometry")));
    }

    /// cadmpeg's example 10 mm cube twice over: the second a copy of every geometry row under
    /// new ids, its body `visible` as given.
    fn two_cubes(second_visible: Option<bool>) -> Model {
        let fixture =
            Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures/synthetic_cube.ipt");
        let part = crate::read(Format::InventorPart, &fixture, &mut Report::default()).unwrap();
        let mut wire = serde_json::to_value(&part.ir).unwrap();
        let model = wire["geometry"].as_object_mut().unwrap();
        let ids: BTreeMap<String, String> = model
            .iter()
            .filter(|(arena, _)| {
                arena.as_str() == "bodies" || !NOT_GEOMETRY.contains(&arena.as_str())
            })
            .flat_map(|(_, rows)| listed(Some(rows)))
            .filter_map(|row| row.get("id").and_then(Value::as_str))
            .map(|id| (id.to_owned(), format!("{id}~copy")))
            .collect();
        fn renamed(value: &Value, ids: &BTreeMap<String, String>) -> Value {
            match value {
                Value::String(s) => json!(ids.get(s).unwrap_or(s)),
                Value::Array(values) => values.iter().map(|v| renamed(v, ids)).collect(),
                Value::Object(fields) => fields
                    .iter()
                    .map(|(k, v)| (k.clone(), renamed(v, ids)))
                    .collect(),
                other => other.clone(),
            }
        }
        for (arena, rows) in model.iter_mut() {
            if arena != "bodies" && NOT_GEOMETRY.contains(&arena.as_str()) {
                continue;
            }
            let rows = rows.as_array_mut().unwrap();
            let copies: Vec<Value> = rows
                .iter()
                .map(|row| {
                    let mut copy = renamed(row, &ids);
                    if arena == "bodies" {
                        match second_visible {
                            Some(visible) => copy["visible"] = json!(visible),
                            None => {
                                if let Some(fields) = copy.as_object_mut() {
                                    fields.remove("visible");
                                }
                            }
                        }
                    }
                    copy
                })
                .collect();
            rows.extend(copies);
        }
        Model {
            ir: cadmpeg_ir::CadIr::from_json(&wire.to_string()).unwrap(),
            ..part
        }
    }

    /// Synthetic final box and a stored cylinder tool, with a cut referring to that tool.
    fn fusion_cut() -> Model {
        let fixture =
            Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures/synthetic_cube.ipt");
        let mut model =
            crate::read(Format::InventorPart, &fixture, &mut Report::default()).unwrap();
        let mut wire = serde_json::to_value(&model.ir).unwrap();
        let m = &mut wire["geometry"];
        let id = |arena: &str, key: usize| format!("test:tool:{arena}#{key}");
        let point = |z: f64| json!({"x": 5.0, "y": 5.0, "z": z});
        let axis = json!({"x": 0.0, "y": 0.0, "z": 1.0});
        let reference = json!({"x": 1.0, "y": 0.0, "z": 0.0});
        for (i, z) in [0.0, 10.0].into_iter().enumerate() {
            m["points"].as_array_mut().unwrap().push(json!({
                "id": id("point", i), "position": {"x": 7.0, "y": 5.0, "z": z}}));
            m["vertices"].as_array_mut().unwrap().push(json!({
                "id": id("vertex", i), "point": id("point", i)}));
            m["curves"].as_array_mut().unwrap().push(json!({"id": id("curve", i), "geometry": {"kind":"solved", "value": {"kind": "circle", "center": point(z),
                    "axis": axis, "ref_direction": reference, "radius": 2.0}}}));
            m["edges"].as_array_mut().unwrap().push(json!({"id": id("edge", i), "carrier": {"curve": id("curve", i), "param_range": [0.0, std::f64::consts::TAU]}, "ends": {"start": id("vertex", i), "end": id("vertex", i)}}));
            m["surfaces"].as_array_mut().unwrap().push(json!({"id": id("surface", i), "geometry": {"kind":"solved", "value": {"kind": "plane", "origin": point(z),
                    "normal": axis, "u_axis": reference}}}));
            for (key, face, forward) in [(i, i, i == 1), (i + 2, 2, i == 0)] {
                m["coedges"].as_array_mut().unwrap().push(json!({
                    "id": id("coedge", key), "owner_loop": id("loop", key),
                    "edge": id("edge", i), "radial_next": id("coedge", if key < 2 {key + 2} else {key - 2}),
                    "sense": if forward {"forward"} else {"reversed"}, "pcurves": []}));
                m["loops"].as_array_mut().unwrap().push(json!({
                    "id": id("loop", key), "face": id("face", face),
                    "boundary": {"kind": "ring", "coedges": [id("coedge", key)], "vertex_uses": []}}));
            }
        }
        m["surfaces"].as_array_mut().unwrap().push(json!({"id": id("surface", 2), "geometry": {"kind":"solved", "value": {"kind": "cylinder", "origin": point(0.0),
                "axis": axis, "ref_direction": reference, "radius": 2.0}}}));
        for i in 0..3 {
            m["faces"].as_array_mut().unwrap().push(json!({
                "id": id("face", i), "shell": id("shell", 0), "surface": id("surface", i),
                "sense": if i == 0 {"reversed"} else {"forward"},
                "loops": {"kind": "unspecified", "loops": if i == 2 {
                    vec![id("loop", 2), id("loop", 3)]
                } else {vec![id("loop", i)]}}}));
        }
        m["shells"].as_array_mut().unwrap().push(json!({
            "id": id("shell", 0), "region": id("region", 0),
            "members": []}));
        m["regions"].as_array_mut().unwrap().push(json!({
            "id": id("region", 0), "body": id("body", 0), "shells": [id("shell", 0)]}));
        m["bodies"]
            .as_array_mut()
            .unwrap()
            .push(json!({"id": id("body", 0), "kind": "solid", "visible": false}));
        let target = m["bodies"][0]["id"].clone();
        let m = &mut wire["model"];
        m["product_definitions"] = json!([{"id": "test:model:component#box", "kind": "part", "bodies": [target], "bom_properties": {}, "sketches": []}]);
        m["features"] = json!([{"id": "test:model:feature#cut", "ordinal": 0, "suppressed": false, "outputs": [target], "definition": {"kind": "operation", "value": {"kind": "combine", "value": {"op": "cut", "keep_tools": false, "operands": {"target": {"kind": "bodies", "value": [target]},
                    "tools": {"kind": "bodies", "value": [id("body", 0)]}}, "destination": "target_component"}}}, "dependencies": [], "source_properties": {}, "source_content": []}]);
        model.ir = cadmpeg_ir::CadIr::from_json(&wire.to_string()).unwrap();
        model
    }

    #[test]
    fn fusion_without_removed_bodies_keeps_the_whole_model() {
        let mut model = two_cubes(None);
        model.source_step = Some("stored source".to_owned());
        assert!(filtered(&model, true).unwrap().is_none());
        let expected = serde_json::to_value(&model.ir).unwrap();
        let mut report = Report::default();
        let kept = fusion(model, &mut report);
        assert_eq!(serde_json::to_value(&kept.ir).unwrap(), expected);
        assert_eq!(kept.source_step.as_deref(), Some("stored source"));
        assert!(report.losses().is_empty());
    }

    #[test]
    fn fusion_consumed_tools_leave_one_body_and_one_info_note() {
        let model = fusion_cut();
        let mut report = Report::default();
        let kept = fusion(model, &mut report);
        assert_eq!(kept.ir.geometry.bodies.len(), 1);
        assert_eq!(kept.ir.geometry.faces.len(), 6);
        assert_eq!(kept.ir.model.features.len(), 1);
        assert_eq!(report.losses().len(), 1);
        assert_eq!(report.losses()[0].severity, Severity::Info);
        assert_eq!(
            report.losses()[0].detail,
            "1 bodies Fusion keeps only as consumed tools or removed bodies were not converted"
        );
        assert!(kept.source_step.is_none());
    }

    #[test]
    fn fusion_user_hidden_component_members_are_kept() {
        let mut model = fusion_cut();
        let mut wire = serde_json::to_value(&model.ir).unwrap();
        let tool = wire["geometry"]["bodies"][1]["id"].clone();
        wire["model"]["product_definitions"][0]["bodies"]
            .as_array_mut()
            .unwrap()
            .push(tool);
        model.ir = cadmpeg_ir::CadIr::from_json(&wire.to_string()).unwrap();
        let mut report = Report::default();
        let kept = fusion(model, &mut report);
        assert_eq!(kept.ir.geometry.bodies.len(), 2);
        assert_eq!(kept.ir.geometry.faces.len(), 9);
        assert_eq!(report.losses().len(), 1);
        assert_eq!(report.losses()[0].severity, Severity::Info);
        assert!(report.losses()[0].detail.contains("user-hidden"));
    }

    #[test]
    fn fusion_hidden_bodies_owned_by_placed_assembly_parts_are_kept() {
        let mut model = fusion_cut();
        let mut wire = serde_json::to_value(&model.ir).unwrap();
        let tool = wire["geometry"]["bodies"][1]["id"].clone();
        wire["model"]["product_definitions"]
            .as_array_mut()
            .unwrap()
            .push(json!({"id": "test:model:component#tool", "kind": "part", "bodies": [tool], "bom_properties": {}, "sketches": []}));
        wire["model"]["occurrences"] = json!([{
            "id": "test:model:occurrence#tool", "ordinal": 0,
            "prototype": {"kind": "local", "definition": "test:model:component#tool"},
            "parent": {"kind": "root"}, "transform": crate::placement::IDENTITY,
            "scale": [1, 1, 1], "visible": false}]);
        model.ir = cadmpeg_ir::CadIr::from_json(&wire.to_string()).unwrap();
        let mut report = Report::default();
        let kept = fusion(model, &mut report);
        assert_eq!(kept.ir.geometry.bodies.len(), 2);
        assert_eq!(kept.ir.model.occurrences.len(), 1);
        assert!(report
            .losses()
            .iter()
            .all(|loss| !loss.detail.contains("not converted")));
        // Component membership is protected even when the occurrence itself is hidden.
        assert_eq!(kept.ir.model.product_definitions.len(), 2);
    }

    #[test]
    fn decoded_container_membership_propagates_gui_visibility() {
        let document = json!({"native": {"fcstd": {
            "objects": [{"id": "Part", "type_name": "App::Part"},
                {"id": "Body", "type_name": "PartDesign::Body"}],
            "gui_view_providers": [{"id": "part-view", "object": "Part"},
                {"id": "body-view", "object": "Body"}, {"id": "pad-view", "object": "Pad"}],
            "gui_properties": [
                {"owner": "part-view", "name": "Visibility", "type_name": "App::PropertyBool", "values": [{"tag": "Bool", "attributes": {"value": "false"}}]},
                {"owner": "body-view", "name": "Visibility", "type_name": "App::PropertyBool", "values": [{"tag": "Bool", "attributes": {"value": "true"}}]},
                {"owner": "pad-view", "name": "Visibility", "type_name": "App::PropertyBool", "values": [{"tag": "Bool", "attributes": {"value": "true"}}]}],
            "properties": [
                {"owner": "Part", "name": "Visibility", "type_name": "App::PropertyBool", "values": [{"tag": "Bool", "attributes": {"value": "false"}}]},
                {"owner": "Part", "name": "Group", "links": [{"object": "Body"}]},
                {"owner": "Body", "name": "Group", "links": [{"object": "Pad"}]}]
        }}});
        assert_eq!(
            hidden_objects(&document),
            BTreeSet::from(["Part", "Body", "Pad"])
        );
        let mut own_visibility = document.clone();
        own_visibility["native"]["fcstd"]["gui_properties"][0]["values"][0]["attributes"]
            ["value"] = json!("true");
        assert!(hidden_objects(&own_visibility).is_empty());
        // A cycle is bounded by visited identities rather than the number of paths.
        let mut cycle = document;
        cycle["native"]["fcstd"]["properties"][2]["links"]
            .as_array_mut()
            .unwrap()
            .push(json!({"object": "Part"}));
        assert_eq!(hidden_objects(&cycle).len(), 3);
    }

    #[test]
    fn a_shown_link_keeps_geometry_hidden_in_the_source_container() {
        let document = json!({"geometry": {"bodies": [{"id": "b", "visible": true}]}, "model": {
            "features": [{"native_ref": "Body", "outputs": ["b"]}],
            "product_definitions": [{"id": "part", "kind": "part", "bodies": ["b"], "bom_properties": {}, "sketches": []}],
            "occurrences": [
                {"id": "source", "prototype": {"kind": "local", "definition": "part"}, "native_ref": "Body", "ordinal": 0, "scale": [1, 1, 1]},
                {"id": "link", "prototype": {"kind": "local", "definition": "part"}, "native_ref": "Link", "ordinal": 0, "scale": [1, 1, 1]}]
        }, "native": {"fcstd": {
            "objects": [{"id": "Part", "type_name": "App::Part"}],
            "properties": [
                {"owner": "Part", "name": "Visibility", "type_name": "App::PropertyBool", "values": [{"tag": "Bool", "attributes": {"value": "false"}}]},
                {"owner": "Part", "name": "Group", "links": [{"object": "Body"}]}]
        }}});
        assert!(hidden_bodies(&document).is_empty());
        let mut shown_link = document.clone();
        assert!(propagate_visibility(&mut shown_link));
        assert_eq!(
            shown_link["model"]["occurrences"][0]["visible"],
            json!(false)
        );
        assert!(shown_link["model"]["occurrences"][1]
            .get("visible")
            .is_none());
        assert!(hidden_bodies(&shown_link).is_empty());
        let mut without_link = document;
        let _ = without_link["model"]["occurrences"]
            .as_array_mut()
            .unwrap()
            .pop();
        assert_eq!(
            hidden_bodies(&without_link),
            BTreeSet::from(["b".to_owned()])
        );
    }

    #[test]
    fn hidden_ancestors_override_visible_children_but_shown_instances_survive() {
        let mut model = two_cubes(Some(true));
        let mut wire = serde_json::to_value(&model.ir).unwrap();
        let second = wire["geometry"]["bodies"][1]["id"].clone();
        wire["model"]["product_definitions"] = json!([
            {"id": "test:model:component#container", "kind": "group", "bom_properties": {}, "bodies": [], "sketches": []},
            {"id": "test:model:component#nested", "kind": "group", "bom_properties": {}, "bodies": [], "sketches": []},
            {"id": "test:model:component#part", "kind": "part", "bodies": [second], "bom_properties": {}, "sketches": []},
        ]);
        let occurrence = |id: &str, definition: &str, parent: Value, visible: bool| {
            json!({
            "id": id, "prototype": {"kind": "local", "definition": definition},
            "parent": parent, "ordinal": 0, "transform": crate::placement::IDENTITY,
            "scale": [1, 1, 1], "visible": visible})
        };
        wire["model"]["occurrences"] = json!([
            occurrence(
                "test:model:occurrence#container",
                "test:model:component#container",
                json!({"kind": "root"}),
                false
            ),
            occurrence(
                "test:model:occurrence#nested",
                "test:model:component#nested",
                json!({"kind": "occurrence", "occurrence": "test:model:occurrence#container"}),
                true
            ),
            occurrence(
                "test:model:occurrence#part",
                "test:model:component#part",
                json!({"kind": "occurrence", "occurrence": "test:model:occurrence#nested"}),
                true
            ),
        ]);
        // The filtering policy consumes the neutral occurrence graph, including deeply nested
        // containers. Keep this independent of source-format visibility projection.
        assert!(hidden_bodies(&wire).contains(second.as_str().unwrap()));
        wire["model"]["occurrences"]
            .as_array_mut()
            .unwrap()
            .push(occurrence(
                "test:model:occurrence#shown",
                "test:model:component#part",
                json!({"kind": "root"}),
                true,
            ));
        assert!(!hidden_bodies(&wire).contains(second.as_str().unwrap()));
        let _ = wire["model"]["occurrences"].as_array_mut().unwrap().pop();
        // Other formats state each occurrence's own visibility, so nothing is propagated.
        model.ir = cadmpeg_ir::CadIr::from_json(&wire.to_string()).unwrap();
        assert!(shown(&model).unwrap().is_none());
        wire["native"]["fcstd"] = json!({});
        model.ir = cadmpeg_ir::CadIr::from_json(&wire.to_string()).unwrap();
        let (shown, count) = shown(&model).unwrap().unwrap();
        assert_eq!(count, 1);
        assert_eq!(shown.ir.geometry.bodies.len(), 1);
    }

    #[test]
    fn a_shown_curve_keeps_its_construction_and_basis() {
        let model = two_cubes(Some(false));
        let mut wire = serde_json::to_value(&model.ir).unwrap();
        let m = wire["geometry"].as_object_mut().unwrap();
        // A subset construction of one shown and one hidden edge curve, each over a basis curve
        // of its own: the construction names the curve, nothing names the construction.
        let mut constructions = Vec::new();
        let mut bases = Vec::new();
        for hidden in [false, true] {
            let edge = m["edges"]
                .as_array()
                .unwrap()
                .iter()
                .find(|e| e["id"].as_str().unwrap().ends_with("~copy") == hidden)
                .unwrap()
                .clone();
            let curve = edge["carrier"]["curve"].as_str().unwrap().to_owned();
            let mut basis = m["curves"]
                .as_array()
                .unwrap()
                .iter()
                .find(|c| c["id"] == json!(curve))
                .unwrap()
                .clone();
            basis["id"] = json!(format!("{curve}:basis"));
            bases.push(basis);
            constructions.push(json!({"id": format!("{curve}:construction"), "curve": curve, "definition": {"kind": "subset", "source": format!("{curve}:basis"),
                    "parameter_range": edge["carrier"]["param_range"], "sense": true}}));
        }
        m["curves"].as_array_mut().unwrap().extend(bases);
        m.insert("procedural_curves".to_owned(), json!(constructions));
        let model = Model {
            ir: cadmpeg_ir::CadIr::from_json(&wire.to_string()).unwrap(),
            ..model
        };
        let (shown, _) = shown(&model).unwrap().unwrap();
        let kept = serde_json::to_value(&shown.ir).unwrap();
        let ids = |arena: &str| -> Vec<String> {
            listed(kept["geometry"].get(arena))
                .iter()
                .filter_map(|row| row["id"].as_str().map(str::to_owned))
                .collect()
        };
        let procedural = ids("procedural_curves");
        assert_eq!(procedural.len(), 1, "{procedural:?}");
        assert!(!procedural[0].contains("~copy"));
        let curves = ids("curves");
        assert!(curves
            .iter()
            .any(|id| *id == procedural[0].replace(":construction", ":basis")));
        assert!(!curves.iter().any(|id| id.contains("~copy")));
    }

    #[test]
    fn hidden_bodies_and_their_geometry_are_left_out() {
        let model = two_cubes(Some(false));
        assert_eq!(model.ir.geometry.bodies.len(), 2);
        assert_eq!(model.ir.geometry.faces.len(), 12);
        let (shown, hidden) = shown(&model).unwrap().unwrap();
        assert_eq!(hidden, 1);
        assert_eq!(shown.ir.geometry.bodies.len(), 1);
        assert_eq!(shown.ir.geometry.faces.len(), 6);
        assert_eq!(shown.ir.geometry.edges.len(), 12);
        assert_eq!(
            shown.ir.geometry.bodies[0].id,
            model.ir.geometry.bodies[0].id
        );
    }

    #[test]
    fn blends_keep_their_stored_base_edges_when_hidden_geometry_is_removed() {
        for kind in ["fillet", "chamfer"] {
            let mut model = two_cubes(Some(false));
            let mut wire = serde_json::to_value(&model.ir).unwrap();
            // The stored base is elsewhere: its sample cannot come from the visible cube.
            for (arena, path) in [
                ("points", "/position/x"),
                ("curves", "/geometry/value/origin/x"),
                ("surfaces", "/geometry/value/origin/x"),
            ] {
                for row in wire["geometry"][arena].as_array_mut().unwrap() {
                    if row["id"].as_str().unwrap().ends_with("~copy") {
                        let x = row.pointer_mut(path).unwrap();
                        *x = json!(x.as_f64().unwrap() + 30.0);
                    }
                }
            }
            let body = wire["geometry"]["bodies"][1]["id"].clone();
            let edge = wire["geometry"]["edges"]
                .as_array()
                .unwrap()
                .iter()
                .find(|edge| edge["id"].as_str().unwrap().ends_with("~copy"))
                .unwrap()["id"]
                .clone();
            let dimension = if kind == "fillet" {
                json!({"radius": {"kind": "constant", "radius": 0.5}})
            } else {
                json!({"spec": {"kind": "distance", "distance": 0.5}})
            };
            let mut group = dimension;
            group["edges"] = json!({"kind": "resolved", "value": {
                "edges": [edge], "native": "synthetic base selection"}});
            wire["model"]["features"] = json!([
                {"id": "test:model:feature#base", "ordinal": 0, "outputs": [body], "suppressed": false, "definition": {"kind": "operation", "value": {"kind": "native", "value": {"kind": "synthetic", "parameters": {}}}}, "dependencies": [], "source_properties": {}, "source_content": []},
                {"id": "test:model:feature#blend", "ordinal": 1, "dependencies": ["test:model:feature#base"], "suppressed": false, "definition": {"kind": "operation", "value": {"kind": kind, "value": {"groups": [group]}}}, "source_properties": {}, "source_content": [], "outputs": []}
            ]);
            if kind == "chamfer" {
                wire["model"]["features"][1]["definition"]["value"]["value"]["flip_direction"] =
                    json!(false);
            }
            model.ir = cadmpeg_ir::CadIr::from_json(&wire.to_string()).unwrap();
            let (shown, _) = shown(&model).unwrap().unwrap();
            assert_eq!(shown.ir.geometry.bodies.len(), 1);
            assert!(shown
                .ir
                .geometry
                .edges
                .iter()
                .all(|e| e.id.as_str() != edge.as_str().unwrap()));
            let kept = serde_json::to_value(&shown.ir).unwrap();
            let selection =
                &kept["model"]["features"][1]["definition"]["value"]["value"]["groups"][0]["edges"];
            assert_eq!(selection["kind"], "historical");
            let state = &kept["model"]["feature_input_topologies"][0];
            assert_eq!(state["input_of"], "test:model:feature#blend");
            assert_eq!(state["edges"], json!([edge]));
            assert_eq!(state["edge_geometry"].as_array().unwrap().len(), 1);
            assert!(state["edge_geometry"][0]["interior"].is_object());
            assert!(state["edge_geometry"][0]["interior"]["x"].as_f64().unwrap() >= 30.0);
            assert!(state["edge_geometry"][0]["tangent"].is_object());
        }
    }

    #[test]
    fn structure_naming_a_hidden_body_still_reads() {
        let mut model = two_cubes(Some(false));
        let mut wire = serde_json::to_value(&model.ir).unwrap();
        let ids: Vec<Value> = listed(wire["geometry"].get("bodies"))
            .iter()
            .map(|body| body["id"].clone())
            .collect();
        wire["model"]["product_definitions"] = json!([{"id": "fcstd:model:component#body", "kind": "part", "label": "Body", "bodies": ids, "bom_properties": {}, "sketches": []}]);
        model.ir = cadmpeg_ir::CadIr::from_json(&wire.to_string()).unwrap();
        let (shown, _) = shown(&model).unwrap().unwrap();
        assert_eq!(shown.ir.geometry.bodies.len(), 1);
    }

    #[test]
    fn sketches_and_their_curves_are_kept_with_the_history() {
        // A FreeCAD sketch's own wire body is hidden; the sketch is still the history's.
        let mut model = two_cubes(Some(false));
        let mut wire = serde_json::to_value(&model.ir).unwrap();
        let sketch = "fcstd:model:sketch#Sketch";
        wire["model"]["sketches"] = json!([{"id": sketch, "name": "Sketch", "placement": {"kind": "resolved", "frame": {
                "origin": {"x": 0.0, "y": 0.0, "z": 0.0},
                "normal": {"x": 0.0, "y": 0.0, "z": 1.0},
                "u_axis": {"x": 1.0, "y": 0.0, "z": 0.0}}}, "profiles": []}]);
        wire["model"]["sketch_entities"] = json!([{"id": "fcstd:model:sketch-entity#1", "sketch": sketch, "geometry": {"kind": "line",
            "start": {"u": 0.0, "v": 0.0}, "end": {"u": 10.0, "v": 0.0}}, "endpoint_refs": [], "construction": false}]);
        model.ir = cadmpeg_ir::CadIr::from_json(&wire.to_string()).unwrap();
        let (shown, _) = shown(&model).unwrap().unwrap();
        assert_eq!(shown.ir.geometry.bodies.len(), 1);
        assert_eq!(shown.ir.geometry.faces.len(), 6);
        assert_eq!(shown.ir.model.sketches.len(), 1);
        assert_eq!(shown.ir.model.sketch_entities.len(), 1);
    }

    #[test]
    fn bodies_shown_or_unstated_are_all_kept() {
        assert!(shown(&two_cubes(Some(true))).unwrap().is_none());
        assert!(shown(&two_cubes(None)).unwrap().is_none());
    }

    #[test]
    fn a_design_hiding_every_body_converts_as_stored() {
        let mut model = two_cubes(Some(false));
        let mut wire = serde_json::to_value(&model.ir).unwrap();
        wire["geometry"]["bodies"][0]["visible"] = json!(false);
        model.ir = cadmpeg_ir::CadIr::from_json(&wire.to_string()).unwrap();
        assert!(shown(&model).unwrap().is_none());
    }
}
